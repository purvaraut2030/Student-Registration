const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mysql = require("mysql");

const app = express();

app.use(cors());
app.use(bodyParser.json());

const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "registration",
});

con.connect((err) => {
  if (err) {
    console.log(err);
  }
  console.log("Database Connected...");
});

// CRUD Operations

// Create Student
app.post("/students", (req, res) => {
  const { firstname, lastname, mobileno, email, addresses } = req.body; // Changed 'address' to 'addresses'

  const studentQuery =
    "INSERT INTO students (firstname, lastname, mobileno, email) VALUES (?, ?, ?, ?)";

  // Insert the student into the database
  con.query(
    studentQuery,
    [firstname, lastname, mobileno, email],
    (err, result) => {
      if (err) {
        console.error("Error inserting student:", err);
        return res.status(500).send(err); // Send the error response and stop execution
      }

      const studentid = result.insertId;

      // Prepare address insertion queries
      const addressQuery = "INSERT INTO address (studentid, address) VALUES ?";
      const addressValues = addresses.map((addr) => [studentid, addr.address1]); // Map the addresses array

      // Insert the addresses into the address table
      con.query(addressQuery, [addressValues], (err) => {
        if (err) {
          console.error("Error inserting addresses:", err);
          return res.status(500).send(err); // Send the error response and stop execution
        }

        res.status(200).send({
          message: "Student and addresses added successfully",
          studentid,
        });
      });
    }
  );
});

// Get All Students
app.get("/students", (req, res) => {
  const query = "SELECT * FROM students";
  con.query(query, (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

// Get Student by ID
app.get("/students/:id", (req, res) => {
    const { id } = req.params;
    const query = "SELECT * FROM students WHERE id = ?";
    
    con.query(query, [id], (err, results) => {
      if (err) {
        return res.status(500).send({ error: "An error occurred while retrieving the student", details: err });
      }
      if (results.length === 0) {
        return res.status(404).send({ message: "Student not found" });
      }
      res.status(200).send(results[0]); // Send the first result (since id is unique)
    });
  });
  
// Edit Student
app.put("/students/:id", (req, res) => {
  const { id } = req.params;
  const { firstname, lastname, mobileno, email } = req.body;

  const query =
    "UPDATE students SET firstname = ?, lastname = ?, mobileno = ?, email = ? WHERE id = ?";
  con.query(query, [firstname, lastname, mobileno, email, id], (err) => {
    if (err) return res.status(500).send(err);
    res.send({ message: "Student updated successfully" });
  });
});

// Delete Student
app.delete("/students/:id", (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM students WHERE id =" + id;
  con.query(query, (err) => {
    if (err) return res.send(err);
    res.send({ message: "Student deleted successfully" });
  });
});

// Get All Addresses
app.get("/address", (req, res) => {
  const query = "SELECT * FROM address";

  con.query(query, (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

// Get Addresses by Student ID
app.get("/address/:studentid", (req, res) => {
  const { studentid } = req.params;
  const query = "SELECT * FROM address WHERE studentid = ?";

  con.query(query, [studentid], (err, results) => {
    if (err) return res.status(500).send(err);
    res.send(results);
  });
});

// Start Server
app.listen(8081, () => {
  console.log(`Server running on https://localhost:8081`);
});
