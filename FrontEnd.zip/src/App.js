
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import RegistrationForm from './RegistrationForm ';
import StudentsList from './StudentsList';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<RegistrationForm />} />
          <Route path='/:id' element={<RegistrationForm />} />
          <Route path='/studentlist' element={<StudentsList />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
