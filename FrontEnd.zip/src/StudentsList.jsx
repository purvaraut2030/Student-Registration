import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const StudentsList = () => {
  const [students, setStudents] = useState([]);

  async function fetchStudentsAndAddresses() {
    try {
      // Fetch both students and addresses data
      const studentsResponse = await axios.get(
        "http://localhost:8081/students"
      );
      const addressesResponse = await axios.get(
        "http://localhost:8081/address"
      );

      const studentsData = studentsResponse.data;
      const addressesData = addressesResponse.data;

      // Create a mapping of addresses by student ID
      const addressMap = addressesData.reduce((acc, address) => {
        // Ensure the correct mapping of studentId to addresses
        if (!acc[address.studentid]) {
          acc[address.studentid] = [];
        }
        // Map each address to its student
        acc[address.studentid].push(address.address);
        return acc;
      }, {});

      // Combine students with their addresses from addressMap
      const combinedData = studentsData.map((student) => ({
        ...student,
        addresses: addressMap[student.id] || [], // Ensure addresses exist for each student
      }));

      setStudents(combinedData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  useEffect(() => {
    fetchStudentsAndAddresses();
  }, []);

  // Handle student deletion

  
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8081/students/${id}`);
      setStudents(students.filter((student) => student.id !== id));
    } catch (err) {
      console.error("Error deleting student:", err);
    }
  };
  

  return (
    <div className="container mt-4">
      <h1>Students List</h1>
      <table className="table">
        <thead>
          <tr>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>Address 1</th>
            <th>Address 2</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => {
            // Safely access the addresses array
            const address1 = student.addresses[0] || "No Address";
            const address2 = student.addresses[1] || "No Address";

            return (
              <tr key={student.id}>
                <td>{student.firstname}</td>
                <td>{student.lastname}</td>
                <td>{student.mobileno}</td>
                <td>{student.email}</td>
                <td>{address1}</td>
                <td>{address2}</td>
                <td>
                  <Link to={"/" + student.id}>
                    <button className="btn btn-warning mx-1"><i class="fa-solid fa-pencil"></i></button>
                  </Link>
                  <button
                    className="btn btn-danger mx-1"
                    onClick={() => handleDelete(student.id)}
                  >
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default StudentsList;
