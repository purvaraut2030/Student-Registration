import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const RegistrationForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [student, setStudent] = useState({
    firstname: "",
    lastname: "",
    mobileno: "",
    email: "",
    addresses: [{ address1: "", address2: "" }],
  });

  const [nameError, setNameError] = useState(undefined);
  const [surnameError, setSurnameError] = useState(undefined);
  const [emailError, setEmailError] = useState(undefined);
  const [mobileError, setMobileError] = useState(undefined);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setStudent({ ...student, [name]: value });
  };

  const handleAddressChange = (index, e) => {
    const newAddresses = [...student.addresses];
    newAddresses[index][e.target.name] = e.target.value;
    setStudent({ ...student, addresses: newAddresses });
  };

  const addAddressField = () => {
    setStudent({
      ...student,
      addresses: [...student.addresses, { address1: "", address2: "" }],
    });
  };

  function handleSubmit(e) {
    e.preventDefault();
    if (id === undefined) {
      axios
        .post("http://localhost:8081/students", student)
        .then((response) => {
          console.log("Student added successfully:", response.data);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
      // Reset form
      setStudent({
        firstname: "",
        lastname: "",
        mobileno: "",
        email: "",
        addresses: [{ address1: "", address2: "" }],
      });
      navigate("/studentlist");
    } else {
      axios
        .put("http://localhost:8081/students/" + id, student)
        .then((response) => {
          console.log("Student updated successfully:", response.data);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
      // Reset form
      setStudent({
        firstname: "",
        lastname: "",
        mobileno: "",
        email: "",
        addresses: [{ address1: "", address2: "" }],
      });

      if (student.firstname.trim() === "") {
        setNameError("Name is Required");
      } else if (student.firstname.trim().length <= 2) {
        setNameError("Above 2 Character Required");
      }
      if (!student.lastname.trim()) {
        setSurnameError("Lastname is Required");
      } else if (student.lastname.trim().length <= 2) {
        setSurnameError("Above 2 Character Required");
      }
  
      if (!student.email.trim()) {
        setEmailError("Email is Required");
      } else if (
        !/[A-Za-z0-9\._%+\-]+@[A-Za-z0-9\.\-]+\.[A-Za-z]{2,}/.test(student.email)
      ) {
        setEmailError("Email is Not Valid");
      }
  
      if (!student.mobileno.trim()) {
        setMobileError("Mobile is Required");
        //  }else if(!/\+?\d{2}\s*\-?\d+/.test(data.mobile)){
      } else if (
        !/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/.test(
          student.mobileno
        )
      ) {
        setMobileError("Mobile is Invalid ");
      }
      navigate("/studentlist");
    }
  }

  useEffect(() => {
    if (id) {
      axios.get("http://localhost:8081/students/" + id).then((res) => {
        console.log(res.data);
        setStudent({
          firstname: res.data.firstname,
          lastname: res.data.lastname,
          mobileno: res.data.mobileno,
          email: res.data.email,
          addresses: [{ address1: "", address2: "" }],
        });
      });
      axios.get("http://localhost:8081/address/" + id).then((res) => {
        console.log(res.data);
        setStudent({
          firstname: res.data.firstname,
          lastname: res.data.lastname,
          mobileno: res.data.mobileno,
          email: res.data.email,
          addresses: [
            { address1: res.data.address, address2: res.data.address },
          ],
        });
      });
    }
  }, []);

  return (
    <>
      <img
        style={{ width: "70px" }}
        src="https://www.nicepng.com/png/detail/110-1101441_student-registration-icon.png"
        alt=""
      />
      <h1 className="mt-2">STUDENT FORM</h1>
      <div className="container mt-4">
        <div className="row justify-content-center">
          <div className="col-lg-4 col-md-6 col-sm-8">
            <form>
              <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  name="firstname"
                  placeholder="Firstname"
                  value={student.firstname}
                  onChange={handleInputChange}
                  required
                />
                 {nameError && (
                          <span className="text-danger">{nameError}</span>
                        )}
              </div>

              <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  name="lastname"
                  placeholder="Lastname"
                  value={student.lastname}
                  onChange={handleInputChange}
                  required
                />
                 {surnameError && (
                          <span className="text-danger">{surnameError}</span>
                        )}
              </div>

              <div className="mb-3">
                <input
                  type="string"
                  className="form-control"
                  name="mobileno"
                  placeholder="Mobileno"
                  value={student.mobileno}
                  onChange={handleInputChange}
                  required
                />
                  {mobileError && (
                          <span className="text-danger">{mobileError}</span>
                        )}
              </div>

              <div className="mb-3">
                <input
                  type="email"
                  className="form-control"
                  name="email"
                  placeholder="Email"
                  value={student.email}
                  onChange={handleInputChange}
                  required
                />
                 {emailError && (
                          <span className="text-danger">{emailError}</span>
                        )}
              </div>

              {student.addresses.map((address, index) => (
                <div key={index} className="mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="address1"
                    placeholder="Address"
                    value={address.address1}
                    onChange={(e) => handleAddressChange(index, e)}
                    required
                  />
                </div>
              ))}

              <button
                type="button"
                className="btn btn-secondary mb-3 mx-1"
                onClick={addAddressField}
              >
                Add Address
              </button>
              <button
                type="submit"
                className="btn btn-primary mb-3 "
                onClick={handleSubmit}
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default RegistrationForm;
